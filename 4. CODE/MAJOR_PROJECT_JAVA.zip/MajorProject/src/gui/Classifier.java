package gui;

import java.io.*;
import java.util.HashMap;

import lexicon_resource.BooleanTwoFloatsChar;
import lexicon_resource.Trie;

public class Classifier {
	
	private static int totalReviews = 0;
	private static int totalPositiveReviews = 0;
	private static int totalNegativeReviews = 0;
	
	private static HashMap<String, Boolean> foodWordsList;
	private static HashMap<String, Boolean> priceWordsList;
	private static float foodRating;
	private static float priceRating;
	
	private static void populateWordLists(){
		foodWordsList = new HashMap<String, Boolean>();
		priceWordsList = new HashMap<String, Boolean>();
		
		BufferedReader br = null;
		
		String word;
		try {
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\food_words.txt"));
			while((word = br.readLine()) != null){
				foodWordsList.put(word.trim().toLowerCase(), true);
			}
			
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\price_words.txt"));
			while((word = br.readLine()) != null){
				priceWordsList.put(word.trim().toLowerCase(), true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Trie createTrie(){
		Trie t = new Trie();
		BufferedReader br = null;

		try {
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\SentiWordNet3.0.txt"));
			br.readLine();
		} catch (Exception e) {
			e.printStackTrace();
		}

		String line;
		try {
			while((line = br.readLine()) != null){
				String[] values = line.split("\t");

				char pos = values[0].charAt(0);
				float posScore = Float.parseFloat(values[2]);
				float negScore = Float.parseFloat(values[3]);

				String[] words = values[4].split(",");
				int numberOfWords = words.length;

				for(int i = 0; i < numberOfWords; i++)
					t.insert(words[i], pos, posScore, negScore);

			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return t;
	}
	
	private static String getOutputFileName(String inputFileName){
		StringBuffer sbuf = new StringBuffer();
		for(int i=0; i<inputFileName.length()-4; i++){
			if(inputFileName.charAt(i) == '\\')
				sbuf.append('\\');
			sbuf.append(inputFileName.charAt(i));
		}
		sbuf.append("Classified.txt");
		
		return sbuf.toString();
	}
	
	private static void classify(Trie t, File file){
		if(file == null)
			System.exit(0);
		
		BufferedReader br = null;
		FileWriter wr = null;
		String line;
		try {
			br = new BufferedReader(new FileReader(file));
			wr = new FileWriter(getOutputFileName(file.getAbsolutePath()));
			wr.flush();
			wr.write("#AnnotatedClass\tClassification\n");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		int totalFoodWords = 0;
		int totalPriceWords = 0;
		float positiveFoodScore = 0.0f;
		float negativeFoodScore = 0.0f;
		float positivePriceScore = 0.0f;
		float negativePriceScore = 0.0f;
		
		try {
			while((line = br.readLine()) != null){
				if(line.startsWith("<Content>")){
					totalReviews++;

					line = line.substring(9).trim();
					line = line.replaceAll("\\p{Punct}", "");					
					String[] words = line.split(" ");
					int numberOfWords = words.length;

					float positiveValue = 0.0f;
					float negativeValue = 0.0f;

					for(int i = 0; i < numberOfWords; i++){
						BooleanTwoFloatsChar thisWord = t.contains(words[i].trim().toLowerCase());
						
						if(foodWordsList.containsKey(words[i])){
							totalFoodWords++;
							int low = i - 5;
							if(low < 0)
								low = 0;
							int high = i + 5;
							if(high > numberOfWords)
								high = numberOfWords;
							for(int j=low; j<high; j++){
								BooleanTwoFloatsChar curWord = t.contains(words[i].trim().toLowerCase());
								positiveFoodScore += curWord.x;
								negativeFoodScore += curWord.y;
							}
						}
						
						if(priceWordsList.containsKey(words[i])){
							totalPriceWords++;
							int low = i - 5;
							if(low < 0)
								low = 0;
							int high = i + 5;
							if(high > numberOfWords)
								high = numberOfWords;
							for(int j=low; j<high; j++){
								BooleanTwoFloatsChar curWord = t.contains(words[i].trim().toLowerCase());
								positivePriceScore += curWord.x;
								negativePriceScore += curWord.y;
							}
						}

						positiveValue += thisWord.x;
						negativeValue += thisWord.y;
					}
					String reviewClass = "";
					if(positiveValue > negativeValue){
						reviewClass = "Positive";
						totalPositiveReviews++;
					}
					else if(positiveValue < negativeValue){
						reviewClass = "Negative";
						totalNegativeReviews++;
					}
					else
						reviewClass = "Neutral";

					line = br.readLine();
					if(line.startsWith("<Class>")){
						line = line.substring(7).trim();

						String lineToWrite = "";
						if(line.equals("Positive") || line.equals("StronglyPositive"))
							lineToWrite = "Positive\t" + reviewClass + "\n";
						else if(line.equals("Negative") || line.equals("StronglyNegative"))
							lineToWrite = "Negative\t" + reviewClass + "\n";
						else if(line.equals("Neutral"))
							lineToWrite = "Neutral\t" + reviewClass + "\n";
						else
							continue;

						wr.write(lineToWrite);
						wr.flush();

					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		foodRating = getRating(totalFoodWords, positiveFoodScore, negativeFoodScore);
		priceRating = getRating(totalPriceWords, positivePriceScore, negativePriceScore);
	}
	
	private static float getRating(int totalWords, float posScore, float negScore){
		int avgTotalMax = totalWords;
		
		int posRating = 0;
		if(posScore > (0.7 * avgTotalMax)){
			posRating = (int) (20 * ((Math.pow(posScore, 2.0))/(Math.pow(avgTotalMax, 2.0))));
			if(posRating > 20)
				posRating = 20;
		}
		else if(posScore < (0.3 * avgTotalMax)){
			posRating = (int) (20 * ((Math.pow(posScore, 0.5))/(Math.pow(avgTotalMax, 0.5))));
			if(posRating > 20)
				posRating = 20;
		}
		else{
			posRating = (int) (20 * (posScore/avgTotalMax));
			if(posRating > 20)
				posRating = 20;
		}
		
		int negRating = 0;
		if(negScore > (0.7 * avgTotalMax)){
			negRating = (int) (20 * ((Math.pow(negScore, 2.0))/(Math.pow(avgTotalMax, 2.0))));
			if(negRating > 20)
				negRating = 20;
		}
		else if(negScore < (0.3 * avgTotalMax)){
			negRating = (int) (20 * ((Math.pow(negScore, 0.5))/(Math.pow(avgTotalMax, 0.5))));
			if(negRating > 20)
				negRating = 20;
		}
		else{
			negRating = (int) (20 * (negScore/avgTotalMax));
			if(negRating > 20)
				negRating = 20;
		}
		
		float rating = (posRating/2.0f) - (negRating/2.0f);
		if(rating < 0.5f)
			rating = 0.5f;
		else if(rating > 10.0f)
			rating = 10.0f;
		
		float margin = (float) (rating - Math.floor(rating));
		if(margin < 0.25f){
			rating = rating - margin;
		}
		else if(margin > 0.75f){
			rating = rating - margin + 1.0f;
		}
		else{
			rating = rating - margin + 0.5f;
		}
		
		return rating;		
	}
	
	public static void main(String[] args) {
		
//		long s = System.currentTimeMillis();
		populateWordLists();
		Trie t = createTrie();
		ChooseFile c = new ChooseFile();
		classify(t, c.getSelection());
		//AnalysisResult ar = new AnalysisResult(totalReviews, totalPositiveReviews, totalNegativeReviews, foodRating, priceRating);
//		long e = System.currentTimeMillis();
//		System.out.println(e-s);
	}
}
