package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import formatting_files.CalculatingSWNEfficiency;
import formatting_files.CleaningSentiWordNet;
import formatting_files.MergingInputFiles;
import lexicon_resource.TrieCreator;

import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;

public class ankit extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ankit frame = new ankit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ankit() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setPreferredSize(new Dimension(10, 15));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
		JLayeredPane layeredPane = new JLayeredPane();
		contentPane.add(layeredPane, BorderLayout.CENTER);
		
		JButton btnEfficiencyCalculation = new JButton("EFFICIENCY CALCULATION");
		btnEfficiencyCalculation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CalculatingSWNEfficiency e = new CalculatingSWNEfficiency();
				e.main(null);
			}
		});
		btnEfficiencyCalculation.setPreferredSize(new Dimension(15, 23));
		btnEfficiencyCalculation.setMinimumSize(new Dimension(23, 23));
		btnEfficiencyCalculation.setMaximumSize(new Dimension(23, 23));
		btnEfficiencyCalculation.setBounds(93, 194, 241, 32);
		layeredPane.add(btnEfficiencyCalculation);
		
		JButton btnMerging = new JButton("MERGING THE ANNOATTED FILES");
		btnMerging.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MergingInputFiles m = new MergingInputFiles();
				m.main(null);
				
				
			}
		});
		btnMerging.setPreferredSize(new Dimension(15, 23));
		btnMerging.setMinimumSize(new Dimension(23, 23));
		btnMerging.setMaximumSize(new Dimension(23, 23));
		btnMerging.setBounds(93, 108, 241, 32);
		layeredPane.add(btnMerging);
		
		JButton btnTrie = new JButton("SENTIMENT CLASSIFICATION");
		btnTrie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TrieCreator t = new TrieCreator();
				t.main(null);
				
			}
		});
		btnTrie.setPreferredSize(new Dimension(15, 23));
		btnTrie.setMinimumSize(new Dimension(23, 23));
		btnTrie.setMaximumSize(new Dimension(23, 23));
		btnTrie.setBounds(93, 151, 241, 32);
		layeredPane.add(btnTrie);
		
		JButton btnCleaning = new JButton("CLEANING SWN");
		btnCleaning.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CleaningSentiWordNet c=new CleaningSentiWordNet();
				c.main(null);
				
				
			
			}
		});
		btnCleaning.setPreferredSize(new Dimension(15, 23));
		btnCleaning.setMinimumSize(new Dimension(23, 23));
		btnCleaning.setMaximumSize(new Dimension(23, 23));
		btnCleaning.setBounds(93, 65, 241, 32);
		layeredPane.add(btnCleaning);
		
		JLabel lblSentimentAnalysis = new JLabel("SENTIMENT ANALYSIS AND OPINION MINING");
		lblSentimentAnalysis.setBounds(93, 20, 241, 34);
		layeredPane.add(lblSentimentAnalysis);
		
		JLabel lblStep = new JLabel("STEP-1");
		lblStep.setBounds(10, 74, 46, 14);
		layeredPane.add(lblStep);
		
		JLabel lblStep_1 = new JLabel("STEP-2");
		lblStep_1.setBounds(10, 117, 46, 14);
		layeredPane.add(lblStep_1);
		
		JLabel lblStep_2 = new JLabel("STEP-3");
		lblStep_2.setBounds(10, 160, 46, 14);
		layeredPane.add(lblStep_2);
		
		JLabel lblStep_3 = new JLabel("STEP-4");
		lblStep_3.setBounds(10, 203, 46, 14);
		layeredPane.add(lblStep_3);
		
		
	}
}
