package gui;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class AnalysisResult extends JFrame { 
	
	public AnalysisResult(int totalReviews, int totalPositiveReviews, int totalNegativeReviews, float foodRating, float priceRating){
		setSize(600, 400);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		JTextArea tArea = new JTextArea();
		tArea.setText("Review Information:"
				+ "\n-------------------------------------"
				+ "\nTotal Reviews: " + totalReviews
				+ "\nTotal Positive Reviews: " + totalPositiveReviews
				+ "\nTotal Negative Reviews: " + totalNegativeReviews
				+ "\nTotal Neutral Reviews: " + (totalReviews - totalPositiveReviews - totalNegativeReviews)
				+ "\n\nRating Information:"
				+ "\n-------------------------------------"
				+ "\nFood Rating: " + foodRating + " out of 5.0"
				+ "\nPrice Rating: " + priceRating + " out of 5.0");
		add(tArea);
		
		setVisible(true);
	}
}
