package gui;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ChooseFile{	
	JFileChooser fc;
	File selectedFile;
	
	public ChooseFile(){		
		fc = new JFileChooser();
		fc.setDialogTitle("Choose a text file..");
		fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
		fc.setFileFilter(new FileNameExtensionFilter("Text file", "txt", "TXT"));
		fc.setCurrentDirectory(new File("E:\\Minor Project\\Minor Project\\"));
		fc.showOpenDialog(null);
		selectedFile = fc.getSelectedFile();
	}
	
	public File getSelection(){
		return selectedFile;
	}
}
