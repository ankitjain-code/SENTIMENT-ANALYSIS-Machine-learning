package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.*;

public class Rating {





	
public static void main(String[] args) {
	
  ArrayList<String> results = new ArrayList<String>();
   JLabel inputLabel1;

	JFrame f2 = new JFrame("Rating");
    inputLabel1 = new JLabel("Rate: ");

    Icon icon1 = new ImageIcon("-favourite-star.png");
    //Icon icon2 = new ImageIcon("-favourite-star.png");
    
    
    
 

    JButton button1 = new JButton(icon1);
    button1.setPreferredSize(new Dimension(35, 35));
    button1.setBorder(BorderFactory.createEmptyBorder());
    button1.setContentAreaFilled(false);
//    button1.setDisabledIcon(icon1);
//    button1.setPressedIcon(icon1);
//    button1.setSelectedIcon(icon1);
//    button1.setRolloverEnabled(true);
//    button1.setRolloverIcon(icon1);
//   button1.setRolloverSelectedIcon(icon1);
    
    JButton b2=new JButton("ankit");

  

    final JTextArea display = new JTextArea(5, 25);

   

    JPanel panel2 = new JPanel();
    f2.add(panel2);
    f2.setVisible(true);
    f2.setSize(500, 550);
    f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    panel2.add(inputLabel1);
    panel2.add(button1);
    panel2.add(b2);
 
   
    panel2.add(display);

    button1.addActionListener(new ActionListener() {

        public void actionPerformed(ActionEvent e) {

            String b1 = "5";
            results.add(b1);
            StringBuilder sb = new StringBuilder();
            for (String string : results) {

                sb.append(string);
                sb.append("\n");
                System.out.println(results.size());
            }

        }
    });
    b2.addActionListener(new ActionListener() {

        public void actionPerformed(ActionEvent e) {

            String b1 = "6";
            results.add(b1);
            StringBuilder sb = new StringBuilder();
            for (String string : results) {

                sb.append(string);
                sb.append("\n");
                System.out.println(results.size());
            }

        }
    });
    
    
}

}

