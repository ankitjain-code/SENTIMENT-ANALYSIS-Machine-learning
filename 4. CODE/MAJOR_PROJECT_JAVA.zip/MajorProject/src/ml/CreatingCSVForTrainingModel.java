package ml;

import java.io.*;

public class CreatingCSVForTrainingModel {

	public static void main(String[] args) {

		BufferedReader br = null;
		FileWriter wr = null;

		try{
			wr = new FileWriter("E:\\Minor Project\\Minor Project\\CombinedData.csv");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try{
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\MergedCleanedData.txt"));
			String line;
			while((line = br.readLine()) != null){
				if(line.startsWith("<author>")){
					StringBuffer lineToWrite = new StringBuffer();
//					System.out.println(line);

					do{
						line = br.readLine(); // read content line
//						System.out.println(line);
					}while(!line.startsWith("<content>"));
					System.out.println(line.substring(9));
					lineToWrite.append(line.substring(9) + ",");

					do{
						line = br.readLine(); // read class line
//						System.out.println(line);
					}while(!line.startsWith("<class>"));
					System.out.println(line.substring(7));
					lineToWrite.append(line.substring(7) + ",");

					do{
						line = br.readLine(); // read locality line
//						System.out.println(line);
					}while(!line.startsWith("<locality>"));
					System.out.println(line.substring(10));
					lineToWrite.append(line.substring(10) + ",");

					do{
						line = br.readLine(); // read food line
//						System.out.println(line);
					}while(!line.startsWith("<food>"));
					System.out.println(line.substring(6));
					lineToWrite.append(line.substring(6) + ",");

					do{
						line = br.readLine(); // read price line
//						System.out.println(line);
					}while(!line.startsWith("<price>"));
					System.out.println(line.substring(7));
					lineToWrite.append(line.substring(7) + ",");

					do{
						line = br.readLine(); // read service line
//						System.out.println(line);
					}while(!line.startsWith("<service>"));
					System.out.println(line.substring(9));
					lineToWrite.append(line.substring(9) + "\n");
					
					wr.write(lineToWrite.toString());
					wr.flush();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
