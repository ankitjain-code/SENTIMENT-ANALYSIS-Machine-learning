package ml;

import java.io.*;

public class CleaningData {
	
	public static final String allowedCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789<> \n\t";
	public static final String punctuations = ",.!&();'\"/\\";
	
	public static void main(String[] args) {
		
		int numberOfFiles = 23;
		String[] filenames = new String[numberOfFiles];
		for(int c=0; c<numberOfFiles; c++)
			filenames[c] = ("ankit" + (c+1));

		BufferedReader br = null;
		FileWriter wr = null;

		try{
			wr = new FileWriter("E:\\Minor Project\\Minor Project\\MergedCleanedData.txt");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try{
			for(String filename: filenames){
				br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\InputFiles1\\" + filename + ".txt"));
				String line;
				while((line = br.readLine()) != null){
//					if(!line.startsWith("<Rating>")){
						String cleanLine = "";
						for(int i=0; i<line.length(); i++){
							 if(allowedCharacters.contains(line.charAt(i) + ""))
								 cleanLine += Character.toLowerCase(line.charAt(i));
							 else if(punctuations.contains(line.charAt(i) + "")){
								 cleanLine += " ";
								 while(i<line.length() - 1 && line.charAt(i+1) == ' ')
									 i++;
							 }
						}
						
						wr.write(cleanLine + "\n");
						wr.flush();
//					}
				}
				wr.write("\n");
				wr.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
