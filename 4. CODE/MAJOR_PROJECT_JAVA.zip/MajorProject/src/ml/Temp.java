package ml;

import java.io.*;

public class Temp {
	
	public static final String[] ALLOWED_CLASSES = {"positive", "neutral", "negative"};
//	public static final String[] ALLOWED_RATINGS = {"0", "1", "2", "3", "4", "5"};
	
	public static void main(String[] args) {
		
//		BufferedReader br = null;
//		FileWriter wr = null;
//
//		try{
//			wr = new FileWriter("G:\\Major Project\\CleanedCombinedDataCompressed.csv");
//			wr.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		try{
//			br = new BufferedReader(new FileReader("G:\\Major Project\\CleanedCombinedData.csv"));
////			int lineCount = 0;
////			int correctClassCount = 0;
////			int erronousLine = 0;
//			String line;
//			while((line = br.readLine()) != null){
////				lineCount++;
//				String[] values = line.split(",");
//				if(values.length < 2){
////					System.out.println(line);
////					erronousLine++;
//					continue;
//				}
//				if(ALLOWED_CLASSES[0].equals(values[1]) /*|| ALLOWED_CLASSES[1].equals(values[1]) || ALLOWED_CLASSES[2].equals(values[1])*/){
////					System.out.println(values[1]);
////					correctClassCount++;
////					System.out.println(line);
////					values[1] = values[1].trim();
////					line = values[0] + "," + values[1] + "," + values[2] + "," + values[3] + "," + values[4] + "," + values[5];
//					if(Math.round((Math.random() * 4)) != 2)
//						continue;
//				}
//
//					wr.write(line + "\n");
//					wr.flush();
////				}
////				else
////					System.out.println(values[1]);
//			}
//			
////			System.out.println(lineCount);
////			System.out.println(correctClassCount);
////			System.out.println(erronousLine);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
//		BufferedReader br = null;
//
//		try{
//			br = new BufferedReader(new FileReader("G:\\Major Project\\CleanedCombinedData.csv"));
//			String line;
//			while((line = br.readLine()) != null){
//				String[] values = line.split(",");
//				if(values.length < 5)
//					continue;
//				if(!(ALLOWED_RATINGS[0].equals(values[3]) || ALLOWED_RATINGS[1].equals(values[3]) || ALLOWED_RATINGS[2].equals(values[3]) || ALLOWED_RATINGS[3].equals(values[3]) || ALLOWED_RATINGS[4].equals(values[3]) || ALLOWED_RATINGS[5].equals(values[3])))
//					System.out.println(values[3]);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	
		BufferedReader br = null;
		FileWriter wr = null;

		try{
			wr = new FileWriter("G:\\Major Project\\ShubhamCleanedCombinedDataCompressed.csv");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try{
			br = new BufferedReader(new FileReader("G:\\Major Project\\ShubhamCleanedCombinedData.csv"));
			String line;
			while((line = br.readLine()) != null){
				String[] values = line.split(",");
				if(values.length < 2)
					continue;
				if(/*!(*/ALLOWED_CLASSES[0].equals(values[1]) /*|| ALLOWED_CLASSES[1].equals(values[1]) || ALLOWED_CLASSES[2].equals(values[1]))*/)
//					line = values[0] + "," + values[1].trim() + "," + values[2] + "," + values[3] + "," + values[4] + "," + values[5];
					if(Math.round((Math.random() * 2)) != 1)
						continue;
				
				wr.write(line + "\n");
				wr.flush();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
}
