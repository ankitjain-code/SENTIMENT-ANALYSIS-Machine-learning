package ml;

import java.io.*;

import gui.Classifier;
import lexicon_resource.*;

public class CreatingAugmentedInputFile {
	
	public static void main(String[] args) {
		Trie t = Classifier.createTrie();
		augmentScoresToReviewsTrainVersion(t);
	}
	
	public static void augmentScoresToReviewsTrainVersion(Trie t){
		BufferedReader br = null;
		FileWriter wr = null;
		String line;
		try {
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\CombinedData.csv"));
			wr = new FileWriter("E:\\Minor Project\\Minor Project\\AugmentedTrainingDataTemp.csv");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			while((line = br.readLine()) != null){
				String[] values = line.split(",");
				if(values.length >= 6){
					String[] words = values[0].split(" ");
					int numberOfWords = words.length;

					float positiveScore = 0.0f;
					float negativeScore = 0.0f;

					for(int i = 0; i < numberOfWords; i++){
						BooleanTwoFloatsChar thisWord = t.contains(words[i].trim().toLowerCase());
						
						positiveScore += thisWord.x;
						negativeScore += thisWord.y;
					}
					
					positiveScore /= words.length;
					negativeScore /= words.length;
					
					String augmentedLine = values[0] + "," + positiveScore + "," + negativeScore + "," + values[1] + "," + values[2] + "," + values[3] + "," + values[4] + "," + values[5];
					
					wr.write(augmentedLine + "\n");
					wr.flush();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
