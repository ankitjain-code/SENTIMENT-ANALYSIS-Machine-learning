package formatting_files;

import java.io.*;


public class CalculatingSWNEfficiency {
	
	public static void main(String[] args) {
		
		BufferedReader br = null;
		
		int total = 0;
		int hits = 0;
		
		try{
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\ReviewClasses.txt"));
			br.readLine();
			String line;
			while((line = br.readLine()) != null){
				total++;
				String[] classes = line.split("\t");
				if(classes.length == 2)
					if(classes[0].equals(classes[1]))
						hits++;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Total: " + total + "\nHits: " + hits + "\nEfficiency: " + ((hits)*100.0)/total);
	}
	
}
