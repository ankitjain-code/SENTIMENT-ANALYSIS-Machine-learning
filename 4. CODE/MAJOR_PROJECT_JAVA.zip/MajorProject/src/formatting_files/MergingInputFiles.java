package formatting_files;

import java.io.*;
import java.util.*;

public class MergingInputFiles {
	
	public static void main(String[] args) {
		
		System.out.println("enter inputs");
		Scanner in = new Scanner(System.in);
		int numberOfFiles = in.nextInt();
		String[] filenames = new String[numberOfFiles];
		for(int c=0; c<numberOfFiles; c++)
			filenames[c] = in.next();
		
		BufferedReader br = null;
		FileWriter wr = null;
		
		try{
			wr = new FileWriter("E:\\Minor Project\\Minor Project\\MergedInput.txt");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try{
			for(String filename: filenames){
				br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\InputFiles1\\" + filename + ".txt"));
				
				String line;
				while((line = br.readLine()) != null){
					line = line.trim();
					wr.write(line + "\n");
					wr.flush();
				}
				wr.write("\n");
				wr.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(" \n SUCCESFULLY CREATED MERGED INPUT FILE");
	}
	
}
