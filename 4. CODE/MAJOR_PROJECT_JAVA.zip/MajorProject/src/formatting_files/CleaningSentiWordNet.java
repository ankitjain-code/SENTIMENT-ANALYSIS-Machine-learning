package formatting_files;

import java.io.*;

public class CleaningSentiWordNet {
	
	public static void main(String[] args) {
		
		BufferedReader br = null;
		FileWriter wr = null;
		
		try {
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\SentiWordNet_3.0.0\\SentiWordNet_3.0.0_20130122.txt"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			wr = new FileWriter("E:\\Minor Project\\Minor Project\\SentiWordNet3.0.txt");
			wr.flush();
			wr.write("#POS\tID\tPosScore\tNegScore\tTerms\n");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		

		String line;
//		int counter = 0;
		try {
			while((line = br.readLine()) != null){
//				line = br.readLine();
//				System.out.println(line);
//				counter++;
				line = line.trim();
				if(!line.startsWith("#")){
					String[] words = line.split("\t");
					if(words.length == 6){
						words[4] = words[4].replaceAll("#\\d*\\s*", ",").trim();
						words[4] = words[4].substring(0, words[4].length() - 1);
						wr.write(words[0] + "\t" + words[1] + "\t" + words[2] + "\t" + words[3] + "\t" + words[4] + "\n");
						wr.flush();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println(" \nSUCCESFULLY CREATED CLEANED SWN FILE");
	}
	
}
