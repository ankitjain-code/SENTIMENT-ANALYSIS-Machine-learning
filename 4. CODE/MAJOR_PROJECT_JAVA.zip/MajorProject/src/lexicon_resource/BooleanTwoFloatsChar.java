package lexicon_resource;

public class BooleanTwoFloatsChar {

	boolean b;
	char c;
	public float x;
	public float y;
	
	public BooleanTwoFloatsChar(){
		b = false;
		c = 'u';
		x = 0.0f;
		y = 0.0f;
	}
	
	public BooleanTwoFloatsChar(boolean p, char s, float q, float r){
		b = p;
		c = s;
		x = q;
		y = r;
	}
	
}
