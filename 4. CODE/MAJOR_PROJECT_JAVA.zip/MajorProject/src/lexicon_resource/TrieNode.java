package lexicon_resource;

import java.util.HashMap;

public class TrieNode {
	 char data;
	 boolean isTerminal;
	 char pos;
	 float positiveScore;
	 float negativeScore;
	 HashMap<Character, TrieNode> children;
	 
	 public TrieNode(char data){
		 this.data = data;
		 this.children = new HashMap<Character, TrieNode>();
	 }
}
