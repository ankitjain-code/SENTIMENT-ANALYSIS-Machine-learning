package lexicon_resource;

import java.io.*;

public class TrieCreator {
	
	public static void main(String[] args) {
		
//		long s = System.currentTimeMillis();
		Trie t = new Trie();
		BufferedReader br = null;
		
		try {
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\SentiWordNet3.0.txt"));
			br.readLine();
		} catch (Exception e) {
			e.printStackTrace();
		}

		String line;
		try {
			while((line = br.readLine()) != null){
				String[] values = line.split("\t");
				
				char pos = values[0].charAt(0);
				float posScore = Float.parseFloat(values[2]);
				float negScore = Float.parseFloat(values[3]);
				
				String[] words = values[4].split(",");
				int numberOfWords = words.length;
				
				for(int i = 0; i < numberOfWords; i++)
					t.insert(words[i], pos, posScore, negScore);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		FileWriter wr = null;
		try {
			br = new BufferedReader(new FileReader("E:\\Minor Project\\Minor Project\\MergedInput.txt"));
			wr = new FileWriter("E:\\Minor Project\\Minor Project\\ReviewClasses.txt");
			wr.flush();
			wr.write("#AnnotatedClass\tClassification\n");
			wr.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			while((line = br.readLine()) != null){
				if(line.startsWith("<Content>")){
					
					line = line.substring(9);
					line = line.replaceAll("\\p{Punct}", "");					
					String[] words = line.split(" ");
					int numberOfWords = words.length;
					
					float positiveValue = 0.0f;
					float negativeValue = 0.0f;
					
					for(int i = 0; i < numberOfWords; i++){
						BooleanTwoFloatsChar thisWord = t.contains(words[i].trim());
						
						positiveValue += thisWord.x;
						negativeValue += thisWord.y;
					}
					String reviewClass = "";
					if(positiveValue > negativeValue)
						reviewClass = "Positive";
					else if(positiveValue < negativeValue)
						reviewClass = "Negative";
					else
						reviewClass = "Neutral";
					
					line = br.readLine();
					if(line.startsWith("<Class>")){
						line = line.substring(7).trim();
						
						String lineToWrite = "";
						if(line.equals("Positive") || line.equals("StronglyPositive"))
							lineToWrite = "Positive\t" + reviewClass + "\n";
						else if(line.equals("Negative") || line.equals("StronglyNegative"))
							lineToWrite = "Negative\t" + reviewClass + "\n";
						else if(line.equals("Neutral"))
							lineToWrite = "Neutral\t" + reviewClass + "\n";
						else
							continue;
						
						wr.write(lineToWrite);
						wr.flush();
						
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
//		long e = System.currentTimeMillis();
		System.out.println(" \n SUCCESFULLY CREATED REVIEW CLASS FILE USING TRIE");
	}
}
