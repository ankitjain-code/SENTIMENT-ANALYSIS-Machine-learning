package lexicon_resource;

public class Trie{
	TrieNode root;
	int wordCount;
	
	public Trie(){
		this.root = new TrieNode('\0');
	}
	
	public int size(){
		return wordCount;
	}
	
	public boolean isEmpty(){
		if(wordCount == 0)
			return true;
		return false;
	}
	
	public BooleanTwoFloatsChar contains(String word){
		TrieNode temp = this.root;
		
		for(int i = 0; i < word.length(); i++){
			TrieNode child = temp.children.get(word.charAt(i));
			if(child == null)
				break;
			
			if(i == word.length() - 1)
				return new BooleanTwoFloatsChar(child.isTerminal, child.pos, child.positiveScore, child.negativeScore);
			
			temp = child;
		}
		
		return new BooleanTwoFloatsChar();
	}
	
	private static void insert(TrieNode node, String word, char pos, float posScore, float negScore){
		if(word.length() == 0){
			node.isTerminal = true;
			node.pos = pos;
			node.positiveScore = posScore;
			node.negativeScore = negScore;
			return;
		}
		
		TrieNode child = node.children.get(word.charAt(0));
		
		if(child == null){
			child = new TrieNode(word.charAt(0));
			node.children.put(word.charAt(0), child);
		}
		
		insert(child, word.substring(1), pos, posScore, negScore);
	}
	
	public void insert(String word, char pos, float posScore, float negScore){
		if(contains(word).b)
			return;
		insert(this.root, word, pos, posScore, negScore);
		wordCount++;
	}
	
	private static void remove(TrieNode node, String word){
		if(word.length() == 0){
			node.isTerminal = false;
			return;
		}
		
		TrieNode child = node.children.get(word.charAt(0));
		
		if(child == null)
			return;
		
		remove(child, word.substring(1));
		
		if(!child.isTerminal && child.children.size() == 0)
			node.children.remove(word.charAt(0));
	}
	
	public void remove(String word){
		if(!contains(word).b)
			return;
		remove(this.root, word);
		wordCount--;
	}
	
}
